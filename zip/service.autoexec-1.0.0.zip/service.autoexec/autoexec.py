import xbmc
xbmc.executebuiltin('ActivateWindow(Videos,addons://sources/video/,return)')
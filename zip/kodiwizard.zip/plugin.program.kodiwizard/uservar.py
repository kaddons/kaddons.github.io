import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://raw.githubusercontent.com/Sanjjay/CustomKodi/master/customkodi.xml'

'''#####-----Notifications File-----#####'''
notify_url  = 'http://[your url]/notify.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
